# The Golden Key, or… How It Really Was

Text-based game "The Golden Key, or… How It Really Was" (Russian: "Золотой ключик, или… Как всё было на самом деле") by Akela (Russian: Акела), Shushkart (Russian: Шушкарт), and an unknown co-author.

The game is in Russian, developed for RipURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#golden_key).

The game was first published on July 9, 2005.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 1F5890B34BA69059255FAF00DD24AC01

## Description

Вы Буратино :). Вас сделал мафиози Карлито по прозвищу \"Плотник\", из гнилого полена...
