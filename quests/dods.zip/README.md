# Demons of the Dark Side: The Black Magician Nostromo

Text-based game "Demons of the Dark Side: The Black Magician Nostromo" (Russian: "Демоны тёмной стороны: Чёрный маг Ностромо") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#dods).

The game was first published on February 18, 2005.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: D3050329EC4F547965F2BB6FB8D44D14

## Description

Всё началось в один погожий летний денёк, когда Вы, как обычно, решили зайти к "Виселому Висельнику", чтобы, как обычно, позавтракать, а заодно и подождать клиентов - вдруг кому-нибудь срочно что-то понадобилось. А вы, надо сказать, занимались в ту пору тем, что решали чужие проблемы любого характера - за соответствующую плату, разумеется. А вот денег тогда вам недоставало...
