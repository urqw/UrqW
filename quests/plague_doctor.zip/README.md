# Plague Doctor

Text-based game "Plague Doctor" (Russian: "Чумной доктор") by Shushkart (Russian: Шушкарт).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#plague_doctor).

The game was first published on February 24, 2019.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: B68201590901C5ED8664298F8A52D58F

## Description

Герой игры - главный врач больницы маленького города, в который попадает против своей воли. Больница приносит небольшую прибыль. Используйте деньги с умом. От этого будет зависеть, что произойдёт с городом и лично с вами.
