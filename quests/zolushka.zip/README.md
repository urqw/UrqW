# Cinderella

Text-based game "Cinderella" (Russian: "Золушка") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#zolushka).

The game was first published on April 24, 2016.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 773E64DD0F1EC91B41D36B15240C9B19

## Description

Это игра для маленьких девочек (достигших 18-летнего возраста) с тремя концовками, моральным выбором и поучительными выводами в конце.
