# Hellish Saturday

Text-based game "Hellish Saturday" (Russian: "Адская суббота") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hellish_saturday).

The game was first published on December 10, 2005.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: CFFAA95ACE458FD709DA7B2F3A417ECD

## Description

Адский город. Адская неделя. Адская работа. Вы просто адски устали. Вы работали в адском видеопрокате. О эти адские фильмы, каждый адский день.
