# Wason Task

Text-based game "Wason Task" (Russian: "Задача Уэйсона") by qwerty.

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#wason_task).

The game was first published on February 24, 2019.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 9DEE06C0A49FE1D09033D3F5EA45758A

## Description

Вольная модификация задачи Уэйсона демонстрирует такой подход к моделированию мира, когда верный вариант невозможно угадать, если выбор был сделан неверно.
