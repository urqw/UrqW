# Dragon Island

Text-based game "Dragon Island" (Russian: "Драконий остров") by Shushkart (Russian: Шушкарт).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#support).

The game was first published on December 21, 2016.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: A4ACD6904673881B3220776584033B0D

## Description

Человечество стоит на грани самоуничтожения. Войны за единственный магический ресурс истощили землю. Но судьба предоставила нашему герою шанс все исправить. Воспользуется ли он им? Смогут ли люди жить в мире и спокойствии? Ответы на эти вопросы вы сможете найти в новой текстовой РПГ от никому не известного автора.
