# Mars 2000

Text-based game "Mars 2000" (Russian: "Марс 2000") by Chicago1920.

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#mars2000).

The game was first published on July 23, 2011.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 9936861750E7BA938B6CF368E0188697

## Description

Я, конечно, подружусь с ними, расскажу, что наша ракета неожиданно взорвалась, — я взорву её на этой же неделе, как только управлюсь с вами, — а потом всех их прикончу. На полвека-то удастся отстоять Марс. Земляне, вероятно, скоро прекратят попытки.
