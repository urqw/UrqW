# Khyfich Island

Text-based game "Khyfich Island" (Russian: "Остров Хйфич") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#99999).

The game was first published on December 21, 2016.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: C42072FB1EF354A73E48CC6AC137255C

## Description

Нъгхлич плыл на плоту, но плот перевернулся. Все камни пропали, все шкуры пропали. Нъгхлича выбросило на берег. Нъгхлич осмотрелся вокруг: побережье. «Нъгхлич!», подумал Нъгхлич. Что означало: «Я верну плот!»
