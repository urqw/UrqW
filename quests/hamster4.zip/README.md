# The Adventures of Brave Hamster Semyon 4: A Bug's Life

Text-based game "The Adventures of Brave Hamster Semyon 4: A Bug's Life" (Russian: "Похождения отважного хомяка Семёна 4: Жизнь жуков") by Mikhail.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster4).

The game was first published on April 15, 2006.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 9911B31B65D2602D5EE65F4C43A39293

## Description

Вы - хомяк по кличке Семён. Если вы прошли предыдущие игры серии, то должны помнить, что вас коварно заточили в клетку, но Вам удалось вырваться на свободу, спуститься со стола и  пробраться к выходу из дома. Теперь вы в роли хомяка Семёна должны пробратся к дороге. Пока всё.
