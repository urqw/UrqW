# Fairy Mound

Text-based game "Fairy Mound" (Russian: "Холм фей") by Belial.

The game is in Russian, developed for RipURQ, URQ_DOS and AkURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#fairy_mound).

The game was first published on June 5, 2006.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 2124E72EE00E30297CE506CCC2CB152F

## Description

Что нужно простому крестьянину, чтобы быть счастливым? Лишь бы хлеб уродился, да лето было не сухим и не холодным, чтоб птицы пели в роще за пашней, вереск на дальнем поле наполнял бы воздух дурманящим ароматом, да зрела медовуха, дожидаясь Праздника Урожая.
