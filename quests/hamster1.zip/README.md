# The Adventures of Brave Hamster Semyon 1: Escape

Text-based game "The Adventures of Brave Hamster Semyon 1: Escape" (Russian: "Похождения отважного хомяка Семёна 1: Побег") by Triangle.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster1).

The game was first published on April 3, 2001.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 529E98B0F00755B12833C13329E1C8EB

## Description

Вы - мирно спящий сирийский хомяк по имени Семён. Вас, пока Вы спали, коварно заточили в клетку. Пока всё.
