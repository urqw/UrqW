# The Chronicles of Captain Blud: The Mystery of the Left Buttock

Text-based game "The Chronicles of Captain Blud: The Mystery of the Left Buttock" (Russian: "Хроники капитана Блуда: Тайна левой ягодицы") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#blud1).

The game was first published on November 15, 2004.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: CC9807BD6B8D48B940F0862EC260C9E2

## Description

Всё началось в один прекрасный день, когда, будучи крайне стеснённым в средствах, и не имеющий желания тяжело и много работать, я решил стать личным биографом капитана Блуда. Как, вы не слышали о капитане Блуде?
