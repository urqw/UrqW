# Cursed City

Text-based game "Cursed City" (Russian: "Проклятый город") by Nikita Belyaev (Russian: Никита Беляев), a.k.a. Nikitoz.

The game is in Russian, developed for RipURQ, adapted for FireURQ by Chicago1920, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#cursed_city).

The game was first published on December 15, 2006.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 66FE0567EA56113CA48E77B38E0DF6F9

## Description

Итак, ты сержант полиции города Ракун Сити. Конечно, это не самая престижная должность, но на жизнь хватает.
