# The Adventures of Sarah Faerman 1: The Dark Secret of the Dark Catacombs

Text-based game "The Adventures of Sarah Faerman 1: The Dark Secret of the Dark Catacombs" (Russian: "Приключения Сары Фаерман 1: Мрачная тайна Катакомб Мрака") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#sarah_faerman1).

The game was first published on September 8, 2009.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 9A0A196BFFC7B01B53BE9D42B5B83491

## Description

На многие мили простирались под Чёрным Городом древние катакомбы. Древнее зло водилось в них, выходя наружу лишь ночью, и повергая в ужас всех обитателей мегаполиса. За ужас и зло исходящее из них, катакомбы назвали Катакомбами Мрака. И никто не мог остановить террор, в который повергли Город ужасные твари из катакомб и их хозяин, вампир Арман.
