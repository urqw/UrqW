$('#mute').hide();
$('.navbar-right').hide();
