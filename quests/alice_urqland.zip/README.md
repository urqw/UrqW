# Alice's Adventures in Urqland

Text-based game "Alice's Adventures in Urqland" by Akela (Russian: Акела).

The game is in Russian, developed for URQ_DOS and AkURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#alice_urqland).

The game was first published on June 5, 2008.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: CB13BADDB440FD92B573C31A16199353

## Description

Неожиданно запахло горелой шерстью, и, из-за камня, выскочил уже знакомый мне кролик. Он выглядел немного опалённым, но это ничуть не уменьшило его болтливости...
