# The Adventures of Brave Hamster Semyon 2: Steep Descent

Text-based game "The Adventures of Brave Hamster Semyon 2: Steep Descent" (Russian: "Похождения отважного хомяка Семёна 2: Крутой спуск") by Triangle.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster2).

The game was first published on April 3, 2001.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 20CCEF59118FD55D597323741C29507E

## Description

Вы - хомяк по кличке Семён. Если вы прошли игру "Похождения отважного хомяка Семёна 1: Побег", то должны помнить, что вас коварно заточили в клетку, вас сторожил кот, а вы, шуганув кота и взломав клетку гвоздём, всё-таки вышли на свободу. Пока всё.
