# The Genie from the Machine

Text-based game "The Genie from the Machine" (Russian: "Джинн из машины") by Evgeniy Tugolukov (Russian: Евгений Туголуков), a.k.a. Korwin.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#genie_from_machine).

The game was first published on October 15, 2006.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 8325E5BCA0A584DF192EE038A65F2A3D

## Description

Свершилось! В начале XXI века великое противостояние совпало с готовностью человечества отправить космолет к Марсу!..
