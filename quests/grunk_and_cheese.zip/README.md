# Grunk and Cheese

Text-based game "Grunk and Cheese" by Admiral Jota.

The game is in English, ported to [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#grunk_and_cheese).

The game was first published on December 16, 2009.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: E9BE5C6CB28D5BB0D416FB8CD99698F9

## Description

Grunk big and green and wearing pants. That good: pants important.
