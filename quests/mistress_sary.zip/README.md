# Mistress Sary

Text-based game "Mistress Sary" (Russian: "Хозяйка Сэри") by Chicago1920.

The game is in Russian, developed for AkURQ, adapted for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#mistress_sary).

The game was first published on June 2, 2006.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 9573B37ADE9E3AF0B695A6237212DA5B

## Description

Что ты знаешь о Ней? Только то, что Она боится света? А знаешь ли ты, что, когда ты сидишь в  полумраке за своим компьютером, Она стоит за твоей спиной и смотрит на тебя.
