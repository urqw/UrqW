# The Adventures of Brave Hamster Semyon 5: On the Road

Text-based game "The Adventures of Brave Hamster Semyon 5: On the Road" (Russian: "Похождения отважного хомяка Семёна 5: На дороге") by Apromix.

The game is in Russian, developed for AkURQ and FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster5).

The game was first published on June 6, 2013.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 22705170430595B1709E736D81BCDC1F

## Description

Вы - хомяк по кличке Семён. Если вы прошли предыдущие игры серии, то должны помнить, что вас коварно заточили в клетку, но ценой неимоверных усилий вам удалось вырваться на свободу. Теперь вы в роли хомяка Семёна оказались за забором на пыльной дороге. Пока всё.
