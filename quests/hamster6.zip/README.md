# The Adventures of Brave Hamster Semyon 6: In the Grove

Text-based game "The Adventures of Brave Hamster Semyon 6: In the Grove" (Russian: "Похождения отважного хомяка Семёна 6: В роще") by Apromix and Simple.

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster6).

The game was first published on June 6, 2012.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: CD45957F5A1C1D7E32106F1E46135395

## Description

Вы - хомяк по кличке Семён. Если вы прошли предыдущие игры серии, то должны помнить, что вас коварно заточили в клетку, но вам удалось вырваться на свободу и покинуть дом и двор, перемахнув через забор. Но и здесь злопамятный кот не оставил Вас в покое. В конце-концов Вам удалось обмануть кота и убежать от него в рощу. Пока всё.
