# A Small Sketch of Great Feelings

Text-based game "A Small Sketch of Great Feelings" (Russian: "Маленькая зарисовка о больших чувствах") by Veta (Russian: Вета).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#small_sketch).

The game was first published on February 15, 2017.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: C3E1F8495A154D3D8B8CB7DE6868D582

## Description

Они сидели вместе на железной скамье и пили ароматный масляный чай с шоколадками. Китайский робот-сборщик и его подопечный, компрессор с идентификационным номером №503D677787, понимали друг друга так, как могут только два китайских устройства...
