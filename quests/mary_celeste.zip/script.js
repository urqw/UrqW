$('#close_game').off('click');
$('#mute').hide();
$('.navbar-right').hide();
