# Mary Celeste

Text-based game "Mary Celeste" (Russian: "Мария Целеста") by Akela (Russian: Акела).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#mary_celeste).

The game was first published on February 15, 2017.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 4A33EC64B80D58E0FAF7C8035A7F128D

## Description

История одного дела знаменитого командора Вуда.
