# Dmitry Smetanin 1: Beginning…

Text-based game "Dmitry Smetanin 1: Beginning…" (Russian: "Дмитрий Сметанин 1: Начало…") by DWIDM (Russian: ДВИДМ).

The game is in Russian, developed for RipURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#dmitry_smetanin1).

The game was first published on February 27, 2003.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 21E49A7B8609A85742FABEB43B512D65

## Description

Родился Дмитрий Сметанин сравнительно недавно - всего каких-то 14 лет назад, а ума у него... Если ум Сметанина оценить по стобальной шкале, то его "умственная оценка" - 0,001. Вот так вот! В данном квесте Вы играете за этого, мягко говоря, не совсем доразвитого мальчика. 
