# The Adventures of Sarah Faerman 2: The Dark Secret of the Dark Barn

Text-based game "The Adventures of Sarah Faerman 2: The Dark Secret of the Dark Barn" (Russian: "Приключения Сары Фаерман 2: Тёмная тайна тёмного хлева") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#sarah_faerman2).

The game was first published on April 4, 2010.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 141603A6943D2AADB4B267D6096166CB

## Description

Была уже поздняя ночь, когда в двери фермы у дороги постучали...
