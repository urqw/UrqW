# Spoiler

Text-based game "Spoiler" (Russian: "Спойлер") by Shushkart (Russian: Шушкарт).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#spoiler).

The game was first published on December 23, 2017.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 510AEB90B3DAB1D64CACA3152A83AE6E

## Description

Все началось в воскресенье утром, хотя нет, раньше. Ночью раздался звонок, которому я сначала не придал никакого значения.
