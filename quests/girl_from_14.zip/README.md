# The Girl from the Fourteenth Floor and the Rain

Text-based game "The Girl from the Fourteenth Floor and the Rain" (Russian: "Та девушка с четырнадцатого этажа и дождь") by Chicago1920.

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#girl_from_14).

The game was first published on February 19, 2013.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 4F2DF7AB3185C0C00F1F30C329416517

## Description

Она нежна... Она чертовски нежна, и её волосы приятно пахнут. Её волосы приятно пахнут морем и закатом,  и я наклоняюсь к ней, чтобы  поцеловать.
