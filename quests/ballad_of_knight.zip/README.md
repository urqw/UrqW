# Ballad of the Knight of the Word and His Bride

Text-based game "Ballad of the Knight of the Word and His Bride" (Russian: "Баллада о рыцаре слова и о его невесте") by Evgeniy Tugolukov (Russian: Евгений Туголуков), a.k.a. Korwin, and Jenny (Russian: Дженни).

The game is in Russian, developed for FireURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#ballad_of_knight).

The game was first published on July 26, 2011.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: A4A403DE7DC8BE07B626690F781D5577

## Description

Был рыцарь Джон и горд, и смел, имел коня и меч, но в жизни большего хотел, о том веду я речь...
