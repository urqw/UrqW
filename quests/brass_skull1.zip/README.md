# The Brass Skull. Chapter One: The Oxbear

Text-based game "The Brass Skull. Chapter One: The Oxbear" (Russian: "Латунный череп. Глава первая: Быкомедведь") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for AkURQ, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#brass_skull1).

The game was first published on November 15, 2013.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: EE5883F4FB43739C61793BBCB0AC8B99

## Description

В далёком будущем, когда земля была уже старой. В Прибалтике, что не так далеко отсюда...
