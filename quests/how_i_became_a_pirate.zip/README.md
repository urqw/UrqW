# How I Became a Pirate

Text-based game "How I Became a Pirate" (Russian: "Как я стал пиратом") by Shushkart (Russian: Шушкарт).

The game is in Russian and developed for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#how_i_became_a_pirate).

The game was first published on November 16, 2015.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 079519D19AD818CB848EEBB2DC07EE05

## Description

Итак, сижу я в баре, пью пиво. И тут заходит какой-то старик, медленно подходит к стойке бара и заказывает два виски, а потом садится на стул рядом со мной.
