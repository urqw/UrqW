# The Adventures of Brave Hamster Semyon 3: On the Floor

Text-based game "The Adventures of Brave Hamster Semyon 3: On the Floor" (Russian: "Похождения отважного хомяка Семёна 3: На полу") by DroZ.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#hamster3).

The game was first published on September 28, 2002.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 234591A7BF84DD97295201DBEBAFB46B

## Description

Вы - хомяк по кличке Семён. Если вы прошли предыдущие игры серии, то должны помнить, что вас коварно заточили в клетку, но Вам удалось вырваться на свободу и спуститься со стола. Теперь вы в роли хомяка Семёна должны пробраться к выходу из дома. Пока всё.
