# The Rice Exchange. Osaka. 18th Century

Text-based game "The Rice Exchange. Osaka. 18th Century" (Russian: "Рисовая Биржа. Осака. XVIII век") by Yuri Pavlenko (Russian: Юрий Павленко), a.k.a. Goraph.

The game is in Russian, developed for URQ_DOS, and adapted for [UrqW](https://github.com/urqw/UrqW) text-based game engine.

This repository contains the source code and other resources of the game. The game is available for launch in the [UrqW engine online catalog](https://urqw.github.io/UrqW/#rice_exchange).

The game was first published on December 31, 2004.

Interactive fiction identifier (IFID) of the game which is its MD5 hash: 878DDFF29E19B52D2E2F6464803C8F5A

## Description

Япония. XVIII век. Умирает старый купец в своём доме. Три сына есть у него. Трёх сыновей зовёт он к себе: "Тот из вас, кто вернётся назад с самой большой сумой денег через 30 дней, и станет моим наследником, и получит от меня в наследство все 10000 йен".
